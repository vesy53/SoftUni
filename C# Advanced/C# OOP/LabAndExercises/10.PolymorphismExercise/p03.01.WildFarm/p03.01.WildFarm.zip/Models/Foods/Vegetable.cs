﻿namespace p03._01.WildFarm.Models.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) 
            : base(quantity)
        {
        }
    }
}
