﻿namespace p06._01.TrafficLights.Enums
{
    public enum ColorAtLight
    {
        Red = 0,
        Green = 1,
        Yellow = 2
    }
}
