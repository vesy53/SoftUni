﻿namespace p06._02.BirthdayCelebrations.Contracts
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
