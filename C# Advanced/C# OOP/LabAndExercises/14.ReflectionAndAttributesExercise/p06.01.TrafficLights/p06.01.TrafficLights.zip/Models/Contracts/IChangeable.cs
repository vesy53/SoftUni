﻿namespace p06._01.TrafficLights.Models.Contracts
{
    public interface IChangeable
    {
        void ChangeLight();
    }
}
