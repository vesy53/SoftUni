﻿namespace p03._01.WildFarm.Models.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
