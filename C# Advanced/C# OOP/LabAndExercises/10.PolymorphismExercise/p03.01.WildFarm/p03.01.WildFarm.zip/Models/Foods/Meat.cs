﻿namespace p03._01.WildFarm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
