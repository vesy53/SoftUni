﻿namespace p05._01.BarrackWars.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
