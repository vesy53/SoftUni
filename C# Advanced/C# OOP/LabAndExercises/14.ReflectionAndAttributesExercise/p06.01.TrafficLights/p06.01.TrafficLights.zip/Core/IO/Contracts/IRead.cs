﻿namespace p06._01.TrafficLights.Core.IO.Contracts
{
    public interface IRead
    {
        string ConsoleReadLine();
    }
}
