﻿namespace p05._01.BarrackWars.Core.AllCommands
{
    using System;

    public class InjectAttribute : Attribute
    {
    }
}
