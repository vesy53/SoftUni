﻿namespace p06._02.BirthdayCelebrations.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
