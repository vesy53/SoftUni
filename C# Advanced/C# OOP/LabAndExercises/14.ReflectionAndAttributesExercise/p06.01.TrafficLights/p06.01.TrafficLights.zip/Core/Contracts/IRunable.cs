﻿namespace p06._01.TrafficLights.Core.Contracts
{
    public interface IRunable
    {
        void Run();
    }
}
