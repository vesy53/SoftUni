﻿namespace p06._02.BirthdayCelebrations.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
