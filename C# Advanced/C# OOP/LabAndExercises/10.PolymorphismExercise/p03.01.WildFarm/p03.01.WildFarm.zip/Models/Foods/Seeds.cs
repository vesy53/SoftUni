﻿namespace p03._01.WildFarm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
