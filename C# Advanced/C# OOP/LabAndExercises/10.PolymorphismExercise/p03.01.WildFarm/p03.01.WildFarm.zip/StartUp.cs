﻿namespace p03._01.WildFarm
{
    using p03._01.WildFarm.Core;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
