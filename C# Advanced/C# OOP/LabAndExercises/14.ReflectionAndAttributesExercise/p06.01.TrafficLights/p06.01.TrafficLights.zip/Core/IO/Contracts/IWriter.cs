﻿namespace p06._01.TrafficLights.Core.IO.Contracts
{
    public interface IWriter
    {
        void ConsoleWrite(string message);
    }
}
